<?php

namespace App\Controllers;

use App\Models\SmashCharacters;

class SmashCharactersController
{
    //funció index
    public function index()
    {
        //obtenim tots els personatges
        $characters = SmashCharacters::getAll();

        //passem els personatges a la vista
        return view('SmashCharacters/index', ['characters' => $characters]);
    }

    //funció per anar a la vista create
    public function create()
    {
        return view('SmashCharacters/create');
    }

    //funció per guardar les dades i tornar a la vista principal
    public function store()
    {
        $data = $_POST;

        // Validate the data
        if (empty($data['name']) || empty($data['franchise']) || empty($data['debut_year']) || empty($data['abilities'])) {
            // Redirect with an error message if the data is not valid
            header('Location: /create');
            exit;
        }

        // Create the character
        SmashCharacters::create($data);

        // Redirect to the index page with a success message
        header('location: /SmashCharacters');
        exit;
    }

    //funció per a la vista edit
    public function edit($id)
    {
        //si no ens passen la id fem redirect
        if ($id === null) {
            header('location: /SmashCharacters');
            exit;
        }

        //busquem el personatge
        $character = SmashCharacters::find($id);

        //si no trobem el personatge, mostrem error 404
        if (!$character) {
            require '../../resources/views/errors/404.blade.php';
            return;
        }

        //retornem la vista i li passem el personatge indicat
        return view('SmashCharacters/edit', ['character' => $character]);
    }

    //funció update per a modificar el personatge a la base de dades
    public function update($id, $data)
    {
        //modifiquem el personatge
        SmashCharacters::update($id, $data);

        //retornem a la pàgina principal
        header('location: /SmashCharacters');
        exit;
    }

    //funció per anar a la vista delete
    public function delete($id)
    {
        //si no ens passen la id fem redirect
        if ($id === null) {
            header('location: /SmashCharacters');
            exit;
        }

        //busquem el personatge
        $character = SmashCharacters::find($id);

        //retornem la vista amb el personatge
        return view('SmashCharacters/delete', ['character' => $character]);
    }

    //funció per eliminar el personatge de la base de dades
    public function destroy($id)
    {
        //utilitzem la funció delete del model
        SmashCharacters::delete($id);

        //retornem a la vista principal
        header('location:  /SmashCharacters');
        exit;
    }
    // Mètode show per mostrar els detalls d'un personatge
    public function show($id)
    {
        $character = SmashCharacters::find($id);
        if (!$character) {
            require '../../resources/views/errors/404.blade.php';
            return;
        }
        return view('SmashCharacters/show', ['character' => $character]);
    }
}