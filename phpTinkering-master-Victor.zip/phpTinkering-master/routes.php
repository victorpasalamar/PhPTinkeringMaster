<?php
//definim les rutes
return [
    '/' => 'App/Controllers/FilmController@index',
    '/index.php' => 'App/Controllers/FilmController@index',
    '/index' => 'App/Controllers/FilmController@index',
    '/home' => 'App/Controllers/FilmController@index',
    '/create' => 'App/Controllers/FilmController@create',
    '/edit' => 'App/Controllers/FilmController@edit',
    '/update' => 'App/Controllers/FilmController@update',
    '/delete' => 'App/Controllers/FilmController@delete',
    '/destroy' => 'App/Controllers/FilmController@destroy',
    '/SmashCharacters' => 'App/Controllers/SmashCharactersController@index',
    '/SmashCharactersindex' => 'App/Controllers/SmashCharacters@index',
    '/SmashCharacterscreate' => 'App/Controllers/SmashCharactersController@create',
    '/SmashCharactersedit' => 'App/Controllers/SmashCharactersController@edit',
    '/SmashCharactersupdate' => 'App/Controllers/SmashCharactersController@update',
    '/SmashCharactersdelete' => 'App/Controllers/SmashCharactersController@delete',
    '/SmashCharactersdestroy' => 'App/Controllers/SmashCharactersController@destroy',
];