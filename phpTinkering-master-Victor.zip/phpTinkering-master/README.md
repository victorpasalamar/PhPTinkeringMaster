# Projecte PHP TINKERING
  - versió 1: Hello world! i sintaxis bàsica
  - versió 2: MVC bàsic
  - versió 3: MVC
  - versió 4: MVC en CRUD
