<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Smash Characters</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Animacions i estils extra */
        .fade-in {
            animation: fadeIn ease 1.5s;
        }
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        @keyframes scaleUp {
            0% { transform: scale(0.8); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body class="bg-gray-900 text-white">

<!-- Hero Section -->
<header class="bg-gray-800 h-screen flex items-center justify-center relative overflow-hidden">
    <div class="absolute inset-0 bg-cover bg-center opacity-50" style="background-image: url('https://cdn.wallpapersafari.com/57/84/f6NeJx.jpg');"></div>
    <div class="relative z-10 text-center max-w-3xl mx-auto">
        <h1 class="text-5xl font-extrabold fade-in mb-6">Discover the World of <span class="text-blue-400">Smash Characters</span></h1>
        <p class="text-lg fade-in text-gray-300 mb-8">Dive into detailed character stats, histories, and explore your favorite films in the Smash universe.</p>
        <a href="#explore" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">Explore Now</a>
    </div>
</header>

<!-- About Section -->
<section id="explore" class="py-24 bg-gray-900">
    <div class="container mx-auto px-6 text-center">
        <h2 class="text-4xl font-bold mb-8 fade-in">Why Explore Smash Characters?</h2>
        <p class="text-lg mb-12 text-gray-300 fade-in max-w-3xl mx-auto">The Smash universe is filled with a rich cast of characters from across gaming history. From their origins to their battle stats, everything you need to know is here. We also provide a catalog of films to complement the lore and excitement of each character.</p>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12 fade-in">
            <!-- Smash Characters Box -->
            <div class="bg-gray-800 p-8 rounded-lg shadow-lg hover:shadow-2xl transition duration-300 ease-in-out transform hover:scale-105">
                <h3 class="text-2xl font-bold mb-4">Smash Characters Table</h3>
                <p class="text-gray-400 mb-6">Discover all characters from the Smash universe, their stats, and battle strategies.</p>
                <a href="/SmashCharacters" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 ease-in-out">View Characters</a>
            </div>

            <!-- Films Box -->
            <div class="bg-gray-800 p-8 rounded-lg shadow-lg hover:shadow-2xl transition duration-300 ease-in-out transform hover:scale-105">
                <h3 class="text-2xl font-bold mb-4">Films Table</h3>
                <p class="text-gray-400 mb-6">Browse through a curated collection of films featuring Smash characters and their adventures.</p>
                <a href="/films" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 ease-in-out">View Films</a>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-24 bg-gray-900">
    <div class="container mx-auto px-6 text-center">
        <h2 class="text-4xl font-bold mb-12 fade-in">What Our Users Are Saying</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12 fade-in">
            <!-- Testimonial 1 -->
            <div class="bg-gray-800 p-8 rounded-lg shadow-lg">
                <p class="text-gray-300 mb-6">"The most comprehensive collection of Smash characters! I use it to improve my game all the time!"</p>
                <h4 class="text-xl font-bold text-blue-400">- Alex</h4>
            </div>

            <!-- Testimonial 2 -->
            <div class="bg-gray-800 p-8 rounded-lg shadow-lg">
                <p class="text-gray-300 mb-6">"An incredible resource for both casual and competitive players. Highly recommended!"</p>
                <h4 class="text-xl font-bold text-blue-400">- Jessica</h4>
            </div>

            <!-- Testimonial 3 -->
            <div class="bg-gray-800 p-8 rounded-lg shadow-lg">
                <p class="text-gray-300 mb-6">"I love how easy it is to navigate through characters and movies. A true fan's dream site!"</p>
                <h4 class="text-xl font-bold text-blue-400">- Michael</h4>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-24 bg-blue-500 text-center">
    <h2 class="text-4xl font-bold text-white mb-4 fade-in">Ready to Dive Into Smash?</h2>
    <p class="text-lg text-white mb-8 fade-in">Join millions of players discovering the best Smash strategies and films.</p>
    <a href="/SmashCharacters" class="bg-white text-blue-500 font-semibold py-3 px-6 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">Get Started</a>
</section>

<!-- Footer -->
<footer class="bg-gray-800 text-gray-400 py-12">
    <div class="container mx-auto px-6 text-center">
        <p>&copy; 2024 Smash Universe. All rights reserved.</p>
        <div class="mt-4">
            <a href="#" class="text-blue-500 hover:underline">Privacy Policy</a> |
            <a href="#" class="text-blue-500 hover:underline">Terms of Service</a>
        </div>
    </div>
</footer>

</body>
</html>