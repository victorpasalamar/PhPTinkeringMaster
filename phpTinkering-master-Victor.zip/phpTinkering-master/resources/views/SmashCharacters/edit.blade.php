<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Smash Character</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-8">
<div class="max-w-lg mx-auto bg-white shadow-md rounded-lg p-6">
    <h1 class="text-3xl font-bold mb-4">Edit Smash Character</h1>
    <form action="/update" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($character->id) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
        <div class="mb-4">
            <label for="name" class="block text-gray-700">Character Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($character->name) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="franchise" class="block text-gray-700">Franchise:</label>
            <input type="text" name="franchise" value="<?= htmlspecialchars($character->franchise) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="debut_year" class="block text-gray-700">Debut Year:</label>
            <input type="number" name="debut_year" value="<?= htmlspecialchars($character->debut_year) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <div class="mb-4">
            <label for="abilities" class="block text-sm font-medium text-gray-700">Abilities:</label>
            <input type="text" name="abilities" value="<?= htmlspecialchars($character->abilities) ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2" required>
        </div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">Edit Character</button>
    </form>
    <a href="/SmashCharacters" class="text-gray-500 hover:underline mt-4 block">Return</a>
</div>
</body>
</html>