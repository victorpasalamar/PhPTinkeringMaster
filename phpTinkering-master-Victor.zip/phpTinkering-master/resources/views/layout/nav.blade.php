<nav class="navbar">
    <div class="nav-links">
        <a href="#">Películ·les</a>
    </div>
</nav>