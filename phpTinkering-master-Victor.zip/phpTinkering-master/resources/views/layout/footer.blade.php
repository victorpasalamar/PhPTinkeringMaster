<footer aria-labelledby="footer-heading">
    <div>
        <div>
            <p >&copy; 2024 Jordi . All rights reserved.</p>
        </div>
    </div>
</footer>
</body>
</html>