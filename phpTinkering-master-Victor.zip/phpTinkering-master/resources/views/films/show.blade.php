<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Details</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-8">
<div class="max-w-4xl mx-auto bg-white shadow-md rounded-lg p-6">
    <h1 class="text-3xl font-bold mb-4">Film Details</h1>
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700">Title:</label>
        <p class="mt-1 block w-full border border-gray-300 rounded-md p-2"><?= htmlspecialchars($film->name) ?></p>
    </div>
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700">Director:</label>
        <p class="mt-1 block w-full border border-gray-300 rounded-md p-2"><?= htmlspecialchars($film->director) ?></p>
    </div>
    <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700">Release Year:</label>
        <p class="mt-1 block w-full border border-gray-300 rounded-md p-2"><?= htmlspecialchars($film->year) ?></p>
    </div>
    <a href="/films" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">Back to Films</a>
</div>
</body>
</html>